package applicationUtilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class screenshot {
	WebDriver driver;
	
	public screenshot(String filepath)
	{
		this.grabscreenshot("E://selenium.png");
	}
	
	public void grabscreenshot(String filepath)
	{
	File src= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);	
	try {
		FileUtils.copyFile(src, new File("E://selenium.png"));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
